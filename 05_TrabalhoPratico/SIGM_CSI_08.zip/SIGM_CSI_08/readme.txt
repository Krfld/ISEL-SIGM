base de dados: my_gis_ta

mudar o psqlPath para a diretory correta

correr os scripts por ordem

NOTAS:

os que começam com 0*_script_... são scripts para configurar as tabelas,
os começados por 1*_script_... são scripts para as popular e
os que começam com 2*_script_... são scripts de simulação,
onde o 20_script_... simula uma trajetória apenas e o 21_script_... simula uma perseguição

para voltar a inicializar a base de dados após um simulação,
basta correr os scripts começados por 1*_script_...