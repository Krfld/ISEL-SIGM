Compiled by Dominik Perpeet
Feb 06 2013

git rev af61cae663 Dec 17, 2012

no fork (not supported in windows)
no flatnodes support (node-persistent-cache)

64 bit node id: osm2pgsql.exe
32 bit node id: osm2pgsql_32bitId.exe

Please keep in mind licenses of all parts:

osm2pgsql (http://wiki.openstreetmap.org/wiki/Osm2pgsql)

versions of libraries:
bzip2 1.0.6
geos 3.3.5
libxml 2.9.0
pgsql 9.2.1
proj 4.8.0
proto_buf_c 0.1.5 (2.4.1)
zlib 1.2.7